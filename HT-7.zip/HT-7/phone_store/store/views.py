from django.shortcuts import render
from .models import Phone

# Create your views here.

def index(request):
    phones = Phone.objects.all()
    return render(request, 'store/index.html', {'phones': phones})
